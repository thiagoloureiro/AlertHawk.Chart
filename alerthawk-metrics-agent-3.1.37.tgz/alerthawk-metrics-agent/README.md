# Helm Chart for AlertHawk Metrics Agent

[![Artifact Hub](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/alerthawk)](https://artifacthub.io/packages/search?repo=alerthawk)

This Helm chart deploys the AlertHawk Metrics Agent, which collects Kubernetes metrics and sends them to the AlertHawk Metrics API.

## Component Deployed

- `alerthawk-metrics` - Metrics collection agent that monitors Kubernetes clusters and sends metrics to the AlertHawk Metrics API

## Prerequisites

- Kubernetes cluster (1.19+)
- Helm 3.x installed
- AlertHawk Metrics API service running (for receiving collected metrics)
- ClickHouse database (external, for the Metrics API to store metrics - not installed by this chart)

## Installation

1. Add the Helm repository:
   ```bash
   helm repo add alerthawk https://thiagoloureiro.github.io/AlertHawk.Chart/
   helm repo update
   ```

2. Configure your `values.yaml` file with the required environment variables (see Configuration section below).

3. Install the chart:
   ```bash
   helm install alerthawk-metrics-agent alerthawk/alerthawk-metrics-agent -f values.yaml
   ```

   Or install from local chart:
   ```bash
   helm install alerthawk-metrics-agent . -f values.yaml
   ```

## Configuration

### Basic Configuration

- `nameOverride`: Override the default deployment name (default: `alerthawk`)
- `replicas`: Number of pod replicas to run (default: `1`)

### Image Configuration

- `image.repository`: Container image repository (default: `thiagoguaru/alerthawk.metrics`)
- `image.tag`: Container image tag/version (default: `3.1.7`)
- `image.pullPolicy`: Image pull policy - `Always`, `IfNotPresent`, or `Never` (default: `Always`)

### Deployment Strategy

- `strategy.type`: Deployment strategy - `RollingUpdate` or `Recreate` (default: `RollingUpdate`)
- `strategy.rollingUpdate.maxSurge`: Maximum number of pods that can be created over desired (default: `25%`)
- `strategy.rollingUpdate.maxUnavailable`: Maximum number of pods unavailable during update (default: `25%`)

### Service Account

- `serviceAccount.create`: Create a new service account (default: `true`)
- `serviceAccount.name`: Kubernetes service account name (default: `alerthawk-sa`)
- `serviceAccount.annotations`: Additional annotations for the service account (optional)
- `serviceAccount.clusterRoleBinding.create`: Create a ClusterRoleBinding to grant permissions (default: `true`)
- `serviceAccount.clusterRoleBinding.clusterRole`: Cluster role to bind to the service account (default: `cluster-admin`)

**Note:** By default, the chart will create a ServiceAccount and bind it to the `cluster-admin` ClusterRole. If you set `serviceAccount.create: false`, you must create the service account and ClusterRoleBinding manually before installing the chart.

### Security Context

- `securityContext.allowPrivilegeEscalation`: Allow privilege escalation (default: `false`)
- `securityContext.privileged`: Run in privileged mode (default: `false`)
- `securityContext.readOnlyRootFilesystem`: Mount root filesystem as read-only (default: `false`)
- `securityContext.runAsNonRoot`: Run as non-root user (default: `false`)

### Resource Limits

Optional resource limits and requests can be configured:

```yaml
resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 100m
    memory: 128Mi
```

### Environment Variables

The following environment variables are required for the metrics agent to function:

#### Required Environment Variables

- `CLUSTER_NAME`: **Required** - Name of the Kubernetes cluster being monitored
  - Example: `aks-tools-01`

- `METRICS_API_URL`: **Required** - Metrics API service URL where collected metrics will be sent
  - Format: `http://service-name.namespace.svc.cluster.local:port`
  - Example: `http://alerthawk-metrics-api.alerthawk.svc.cluster.local:8080`

#### Optional Environment Variables

- `METRICS_COLLECTION_INTERVAL_SECONDS`: Interval in seconds for collecting metrics from Kubernetes (default: `40`)
  - Type: Integer
  - Example: `40`

- `NAMESPACES_TO_WATCH`: Comma-separated list of namespaces to monitor for metrics
  - Example: `alerthawk,clickhouse,production,staging`

- `COLLECT_LOGS`: Enable log collection (default: `false`)
  - Set to `true` to enable log collection
  - Type: String (`"true"` or `"false"`)

- `CLUSTER_ENVIRONMENT`: Environment name for the cluster (default: `PROD`)
  - Example: `PROD`, `DEV`, `STAGING`

- `LOG_LEVEL`: Logging level for Serilog (default: `Information`)
  - Options: `Verbose`, `Debug`, `Information`, `Warning`, `Error`, `Fatal`

- `SENTRY_DSN`: Sentry Data Source Name for error tracking (optional)
  - Leave empty to use default or disable Sentry
  - Example: `https://your-sentry-dsn@sentry.io/project-id`

- `ENVIRONMENT`: Environment name for Sentry error tracking (default: `Production`)
  - Example: `Production`, `Development`, `Staging`

## Example values.yaml

```yaml
nameOverride: "alerthawk"
replicas: 1

image:
  repository: thiagoguaru/alerthawk.metrics
  tag: "3.1.7"
  pullPolicy: Always

strategy:
  type: RollingUpdate
  rollingUpdate:
    maxSurge: 25%
    maxUnavailable: 25%

serviceAccount:
  create: true
  name: alerthawk-sa
  clusterRoleBinding:
    create: true
    clusterRole: cluster-admin

securityContext:
  allowPrivilegeEscalation: false
  privileged: false
  readOnlyRootFilesystem: false
  runAsNonRoot: false

env:
  # Required
  CLUSTER_NAME: "aks-tools-01"
  METRICS_API_URL: "http://alerthawk-metrics-api.alerthawk.svc.cluster.local:8080"
  
  # Optional - Collection settings
  METRICS_COLLECTION_INTERVAL_SECONDS: "40"
  NAMESPACES_TO_WATCH: "alerthawk,clickhouse"
  COLLECT_LOGS: "false"
  
  # Optional - Cluster information
  CLUSTER_ENVIRONMENT: "PROD"
  
  # Optional - Logging
  LOG_LEVEL: "Information"
  
  # Optional - Sentry error tracking
  SENTRY_DSN: ""
  ENVIRONMENT: "Production"
```

## Rancher UI Configuration

This chart includes `questions.yml` and `values.schema.json` files that enable a user-friendly form interface in Rancher. When deploying through Rancher, you'll see organized form fields for:

- Basic configuration (replicas, name override)
- Image settings (repository, tag, pull policy)
- Deployment strategy
- Environment variables (all configurable with descriptions)
- Security context settings
- Resource limits and requests

## What the Metrics Agent Does

The AlertHawk Metrics Agent:

1. **Monitors Kubernetes Resources**: Collects metrics from pods, deployments, services, and other resources in specified namespaces
2. **Sends to Metrics API**: Forwards collected metrics to the AlertHawk Metrics API service
3. **Configurable Collection**: Allows you to specify which namespaces to monitor and how frequently to collect metrics
4. **Cluster Identification**: Tags metrics with the cluster name for multi-cluster environments

## Troubleshooting

### Metrics not being collected

- Verify the `METRICS_API_URL` is correct and accessible from the pod
- Check that the service account has proper permissions to read Kubernetes resources
- Ensure the specified namespaces exist and are accessible

### Connection issues

- Verify the `METRICS_API_URL` is correct and accessible
- Check network connectivity between the metrics agent and the Metrics API service
- Ensure the Metrics API service is running and accessible

### Pod not starting

- Check pod logs: `kubectl logs -n <namespace> <pod-name>`
- Verify all required environment variables are set
- Check service account exists: `kubectl get serviceaccount alerthawk-sa -n <namespace>`

## Uninstallation

To uninstall the chart:

```bash
helm uninstall alerthawk-metrics-agent
```

## Support

For issues and questions, please visit:
- GitHub: https://github.com/thiagoloureiro/AlertHawk.Chart
- Artifact Hub: https://artifacthub.io/packages/search?repo=alerthawk